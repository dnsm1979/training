from django.contrib import admin
from .models import Products

admin.site.register(Products)
