from django.contrib import admin
from .models import Positions, Sellers

admin.site.register(Positions)
admin.site.register(Sellers)
